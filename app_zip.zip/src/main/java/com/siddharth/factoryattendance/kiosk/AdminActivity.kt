package com.siddharth.factoryattendance.kiosk

import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class AdminActivity : AppCompatActivity() {

    private lateinit var dbHelper: AttendanceDbHelper
    private lateinit var reportText: TextView
    private lateinit var btnAddIn: Button
    private lateinit var btnAddOut: Button
    private lateinit var btnExportCsv: Button

    private val dbExecutor = Executors.newSingleThreadExecutor()

    private val autoLockHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val AUTO_LOCK_MS = 60_000L

    private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val isAuthorized = intent.getBooleanExtra("ADMIN_AUTH", false)
        if (!isAuthorized) {
            finish()
            return
        }

        setContentView(R.layout.activity_admin)

        AppState.isAdminModeActive = true
        resetAutoLock()

        dbHelper = AttendanceDbHelper(this)

        reportText = findViewById(R.id.reportText)
        btnAddIn = findViewById(R.id.btnAddIn)
        btnAddOut = findViewById(R.id.btnAddOut)
        btnExportCsv = findViewById(R.id.btnExportCsv)

        btnAddIn.setOnClickListener { showManualPunchDialog(PunchType.IN) }
        btnAddOut.setOnClickListener { showManualPunchDialog(PunchType.OUT) }
        btnExportCsv.setOnClickListener { exportCsvToDownloads() }

        ensureDefaultWorkerExists()
        refreshReportAsync()
    }

    private fun ensureDefaultWorkerExists() {
        val db = dbHelper.writableDatabase
        db.execSQL("INSERT OR IGNORE INTO workers (id, name, rfid_uid) VALUES (1,'Siddharth','0030676666')")
    }

    private fun showManualPunchDialog(type: PunchType) {
        Log.d("ADMIN", "Opening manual dialog for $type")

        val input = EditText(this)
        input.hint = "Reason (required)"

        AlertDialog.Builder(this)
            .setTitle("Manual ${type.name}")
            .setView(input)
            .setPositiveButton("Confirm") { _, _ ->
                val reason = input.text.toString().trim()

                // ✅ FIX: if EMPTY => block. if NOT EMPTY => proceed.
                if (reason.isEmpty()) {
                    reportText.text = "❌ Reason is required"
                    reportText.setTextColor(Color.RED)
                    return@setPositiveButton
                }

                addManualPunchAsync(type, reason)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addManualPunchAsync(type: PunchType, reason: String) {
        reportText.text = "Saving..."
        reportText.setTextColor(Color.YELLOW)

        dbExecutor.execute {
            val now = System.currentTimeMillis()
            val db = dbHelper.writableDatabase

            try {
                db.beginTransaction()

                val c = db.rawQuery("SELECT id FROM workers ORDER BY id LIMIT 1", null)
                val hasWorker = c.moveToFirst()
                val workerId = if (hasWorker) c.getInt(0) else null
                c.close()

                if (workerId == null) {
                    runOnUiThread {
                        reportText.text = "❌ No workers found. Seed workers first."
                        reportText.setTextColor(Color.RED)
                    }
                    return@execute
                }

                db.execSQL(
                    "INSERT INTO punches (worker_id, type, timestamp) VALUES (?, ?, ?)",
                    arrayOf(workerId, type.name, now)
                )

                db.execSQL(
                    "INSERT INTO audit_log (event_type, worker_id, details, timestamp) VALUES (?, ?, ?, ?)",
                    arrayOf("MANUAL_${type.name}", workerId, reason, now)
                )

                db.setTransactionSuccessful()

                runOnUiThread {
                    reportText.text = "✅ Saved manual ${type.name} @ ${fmt.format(Date(now))}"
                    reportText.setTextColor(Color.GREEN)
                }

            } catch (e: Exception) {
                Log.e("ADMIN", "Manual punch failed", e)
                runOnUiThread {
                    reportText.text = "❌ Failed:\n${e.javaClass.simpleName}\n${e.message}"
                    reportText.setTextColor(Color.RED)
                }
            } finally {
                if (db.inTransaction()) db.endTransaction()
            }

            refreshReportAsync()
        }
    }

    private fun refreshReportAsync() {
        dbExecutor.execute {
            try {
                val db = dbHelper.readableDatabase

                val cursor = db.rawQuery(
                    """
                    SELECT COALESCE(w.name,'Unknown'), p.type, p.timestamp
                    FROM punches p
                    LEFT JOIN workers w ON w.id = p.worker_id
                    ORDER BY p.timestamp DESC
                    LIMIT 200
                    """.trimIndent(),
                    null
                )

                val sb = StringBuilder()
                sb.append("TODAY'S ATTENDANCE (last 200)\n\n")

                if (cursor.count == 0) {
                    sb.append("No attendance yet.")
                } else {
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(0)
                        val type = cursor.getString(1)
                        val ts = cursor.getLong(2)
                        sb.append("$name - $type @ ${fmt.format(Date(ts))}\n")
                    }
                }

                cursor.close()

                runOnUiThread {
                    reportText.text = sb.toString()
                    reportText.setTextColor(Color.WHITE)
                }
            } catch (e: Exception) {
                Log.e("ADMIN", "Report load failed", e)
                runOnUiThread {
                    reportText.text = "❌ Failed to load report:\n${e.javaClass.simpleName}\n${e.message}"
                    reportText.setTextColor(Color.RED)
                }
            }
        }
    }

    private fun exportCsvToDownloads() {
        reportText.text = "Exporting CSV..."
        reportText.setTextColor(Color.YELLOW)

        dbExecutor.execute {
            try {
                val db = dbHelper.readableDatabase
                val cursor = db.rawQuery(
                    """
                    SELECT w.name, p.type, p.timestamp
                    FROM punches p
                    JOIN workers w ON w.id = p.worker_id
                    ORDER BY p.timestamp ASC
                    """.trimIndent(),
                    null
                )

                val fileName = "attendance_${System.currentTimeMillis()}.csv"
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }

                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Failed to create download file")

                contentResolver.openOutputStream(uri).use { out ->
                    if (out == null) throw IllegalStateException("Failed to open output stream")

                    out.write("Name,Type,Timestamp\n".toByteArray())

                    while (cursor.moveToNext()) {
                        val name = cursor.getString(0)
                        val type = cursor.getString(1)
                        val ts = cursor.getLong(2)
                        val dt = fmt.format(Date(ts))

                        // Quote fields to keep Excel sane
                        val line = "\"$name\",\"$type\",\"$dt\"\n"
                        out.write(line.toByteArray())
                    }
                }

                cursor.close()

                runOnUiThread {
                    reportText.text = "✅ CSV saved to Downloads:\n$fileName"
                    reportText.setTextColor(Color.GREEN)
                }

            } catch (e: Exception) {
                Log.e("CSV", "Export failed", e)
                runOnUiThread {
                    reportText.text = "❌ Export failed:\n${e.javaClass.simpleName}\n${e.message}"
                    reportText.setTextColor(Color.RED)
                }
            }
        }
    }

    private fun resetAutoLock() {
        autoLockHandler.removeCallbacksAndMessages(null)
        autoLockHandler.postDelayed({ finish() }, AUTO_LOCK_MS)
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        resetAutoLock()
        return super.dispatchTouchEvent(ev)
    }

    override fun onDestroy() {
        super.onDestroy()
        autoLockHandler.removeCallbacksAndMessages(null)
        AppState.isAdminModeActive = false
    }
}
