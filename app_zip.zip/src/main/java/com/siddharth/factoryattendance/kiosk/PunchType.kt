package com.siddharth.factoryattendance.kiosk

enum class PunchType {
    IN,
    OUT
}