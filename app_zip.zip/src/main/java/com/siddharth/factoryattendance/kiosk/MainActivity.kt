package com.siddharth.factoryattendance.kiosk

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import android.os.Handler
import android.os.Looper
import android.util.Log

data class Worker(val id: Int, val name: String, val rfidUid: String)
data class Punch(val workerId: Int, val type: PunchType, val timestamp: Long)

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: AttendanceDbHelper

    private lateinit var adminTouchZone: View
    private val adminHandler = Handler(Looper.getMainLooper())
    private var adminRunnable: Runnable? = null

    private val uidBuffer = StringBuilder()
    private lateinit var statusText: TextView

    private val COOLDOWN_MS = 5_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dbHelper = AttendanceDbHelper(this)

        setContentView(R.layout.activity_main)

        adminTouchZone = findViewById(R.id.adminTouchZone)
        statusText = findViewById(R.id.statusText)

        seedDefaultWorker()
        debugDumpWorkers()
        setupAdminHold()

        // Kiosk-style fullscreen
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        statusText.text = "Tap RFID Card"
        statusText.setTextColor(Color.GREEN)
    }

    // ---------------- ADMIN LONG PRESS ----------------

    private fun setupAdminHold() {
        adminTouchZone.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    adminRunnable = Runnable { showAdminPinDialog() }
                    adminHandler.postDelayed(adminRunnable!!, 5000)
                    true
                }
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> {
                    adminRunnable?.let { adminHandler.removeCallbacks(it) }
                    true
                }
                else -> false
            }
        }
    }

    // ---------------- RFID INPUT ----------------

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {

            if (event.keyCode == KeyEvent.KEYCODE_ENTER) {
                val raw = uidBuffer.toString()
                uidBuffer.clear()
                if (raw.isNotBlank()) handleScannedCard(raw)
                return true
            }

            val ch = event.unicodeChar.toChar()
            if (ch.isDigit()) {
                uidBuffer.append(ch)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------------- CORE FLOW ----------------

    private fun handleScannedCard(rawUid: String) {
        val cleanUid = rawUid.trim().replace(Regex("[^0-9]"), "")
        Log.d("RFID", "Raw='$rawUid' | Clean='$cleanUid' | len=${cleanUid.length}")

        if (cleanUid.isEmpty()) {
            statusText.text = "❌ Invalid Card"
            statusText.setTextColor(Color.RED)
            return
        }

        val worker = getWorkerByUid(cleanUid)
        if (worker == null) {
            statusText.text = "❌ Unknown Card"
            statusText.setTextColor(Color.RED)
            debugDumpWorkers()
            return
        }

        val now = System.currentTimeMillis()
        val lastPunch = getLastPunchForWorker(worker.id)

        if (lastPunch != null && now - lastPunch.timestamp < COOLDOWN_MS) {
            statusText.text = "⚠️ Please wait..."
            statusText.setTextColor(Color.YELLOW)
            return
        }

        val nextType =
            if (lastPunch == null || lastPunch.type == PunchType.OUT)
                PunchType.IN
            else
                PunchType.OUT

        val punch = Punch(worker.id, nextType, now)

        val punchId = savePunchAndReturnId(punch)
        statusText.text = "✅ ${worker.name} - ${nextType.name}"
        statusText.setTextColor(Color.CYAN)

        launchCameraForPunch(punchId)
    }

    // ---------------- DB HELPERS ----------------

    private fun seedDefaultWorker() {
        val db = dbHelper.writableDatabase
        db.execSQL(
            "INSERT OR IGNORE INTO workers (id, name, rfid_uid) VALUES (1, 'Siddharth', '0030676666')"
        )
        Log.d("DB", "Seeded default worker")
    }

    private fun getWorkerByUid(uid: String): Worker? {
        val db = dbHelper.readableDatabase
        val c = db.rawQuery(
            "SELECT id, name, rfid_uid FROM workers WHERE rfid_uid = ?",
            arrayOf(uid)
        )

        val worker =
            if (c.moveToFirst())
                Worker(c.getInt(0), c.getString(1), c.getString(2))
            else null

        c.close()
        return worker
    }

    private fun getLastPunchForWorker(workerId: Int): Punch? {
        val db = dbHelper.readableDatabase
        val c = db.rawQuery(
            "SELECT worker_id, type, timestamp FROM punches WHERE worker_id=? ORDER BY timestamp DESC LIMIT 1",
            arrayOf(workerId.toString())
        )

        val punch =
            if (c.moveToFirst())
                Punch(
                    workerId = c.getInt(0),
                    type = PunchType.valueOf(c.getString(1)),
                    timestamp = c.getLong(2)
                )
            else null

        c.close()
        return punch
    }

    // 🔥 REPLACED METHOD (IMPORTANT)
    private fun savePunchAndReturnId(p: Punch): Long {
        val db = dbHelper.writableDatabase
        val stmt = db.compileStatement(
            "INSERT INTO punches (worker_id, type, timestamp) VALUES (?, ?, ?)"
        )
        stmt.bindLong(1, p.workerId.toLong())
        stmt.bindString(2, p.type.name)
        stmt.bindLong(3, p.timestamp)
        val id = stmt.executeInsert()
        Log.d("DB", "Saved punch id=$id worker=${p.workerId} type=${p.type}")
        return id
    }

    // ---------------- CAMERA ----------------

    private fun launchCameraForPunch(punchId: Long) {
        val intent = Intent(this, CameraCaptureActivity::class.java)
        intent.putExtra(CameraCaptureActivity.EXTRA_PUNCH_ID, punchId)
        startActivity(intent)
    }

    // ---------------- ADMIN ----------------

    private fun showAdminPinDialog() {
        val input = EditText(this)
        input.inputType =
            android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        input.hint = "Enter Admin PIN"

        AlertDialog.Builder(this)
            .setTitle("Admin Access")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Unlock") { _, _ ->
                val pin = input.text.toString().trim()
                if (pin == "1234") {
                    launchAdmin()
                } else {
                    statusText.text = "❌ Invalid PIN"
                    statusText.setTextColor(Color.RED)
                    logAudit("ADMIN_PIN_FAILED", null, "Wrong PIN attempt")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun logAudit(eventType: String, workerId: Int?, details: String) {
        val db = dbHelper.writableDatabase
        db.execSQL(
            "INSERT INTO audit_log (event_type, worker_id, details, timestamp) VALUES (?, ?, ?, ?)",
            arrayOf(eventType, workerId, details, System.currentTimeMillis())
        )
    }

    private fun launchAdmin() {
        val intent = Intent(this, AdminActivity::class.java)
        intent.putExtra("ADMIN_AUTH", true)
        startActivity(intent)
    }

    private fun debugDumpWorkers() {
        val db = dbHelper.readableDatabase
        val c = db.rawQuery("SELECT id, name, rfid_uid FROM workers", null)
        Log.d("DB", "---- WORKERS TABLE ---- count=${c.count}")
        while (c.moveToNext()) {
            Log.d("DB", "id=${c.getInt(0)} name=${c.getString(1)} uid='${c.getString(2)}'")
        }
        c.close()
    }

    override fun onPause() {
        super.onPause()
        if (!AppState.isAdminModeActive) {
            moveTaskToBack(false)
        }
    }
}
